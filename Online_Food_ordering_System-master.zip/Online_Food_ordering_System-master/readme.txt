Project Preview
1."Online_Food_Ordering_System"



**LOGIN DETAILS** 

Admin
user: admin
pass: admin123



![](https://user-images.githubusercontent.com/30683532/114361195-abd28680-9b97-11eb-9135-a75e24979ec0.gif)

